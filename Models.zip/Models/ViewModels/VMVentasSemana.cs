﻿namespace SistemaVenta.AplicacionWeb.Models.ViewModels
{
    public class VMVentasSemana
    {
        public string? Fecha { get; set; }
        public int Total { get; set; }

    }
}
