﻿namespace SistemaVenta.AplicacionWeb.Models.ViewModels
{
    public class VMCambiarClave
    {
        public string? claveActual { get; set; }
        public string? claveNueva { get; set; }
    }
}
