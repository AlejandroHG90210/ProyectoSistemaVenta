﻿using System;
using System.Collections.Generic;

namespace SistemaVenta.Entity
{
    public partial class Configuracion
    {
        public string? Recurso { get; set; }
        public string? Propiedad { get; set; }
        public string? Valor { get; set; }
    }
}
